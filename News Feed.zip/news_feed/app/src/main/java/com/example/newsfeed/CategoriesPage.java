package com.example.newsfeed;

public class CategoriesPage {
}
